# plat_disease_recognition
helps recognize plannt diseases
